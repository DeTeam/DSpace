module GameEngine

  class Base 
    
    def initialize

      $s.background $s.fill 'images/logo.gif'
      
      @sboard = $s.para '0', :align => 'right', :fill => $s.white
      $s.para 'Scores: ', :align => 'right', :fill => $s.white

      @bullets = []
      @npc = []
      @char = Ship.new(200, 550, $s.image('images/char.gif'))
      @scores = 0

      send_npc
      $s.every(10) { send_npc }
      

      $s.keypress do |key|
        case key
        when :left
          @char.move(-10, 0)
        when :right
          @char.move(10, 0)
        when ' '
          x = @char.x + 20
          y = @char.y + 20
          @bullets << Bullet.new(x, y)
        end
      end


    end
    
    def start
      $s.animate(20) do |i|
        @npc.each { |npc| npc.move; npc.render }
        @char.render
        @bullets.each do |bullet|
          bullet.move
          bullet.render
          @npc.each do |npc|
            if bullet.x > npc.x && bullet.x < npc.x + npc.image.full_width && bullet.y > npc.y  && bullet.y < npc.y + npc.image.full_height
              bullet.image.remove
              @bullets.delete(bullet)
              @npc.delete(npc)
              npc.image.remove
              @scores += 1
              @sboard.text = @scores
            end
          end
          if bullet.life > 100
            bullet.image.remove
            @bullets.delete(bullet)
          end
        end
      end
    end

    def send_npc
      12.times do |i|
        @npc << NPC.new(i*50, 15, $s.image("images/npc#{i%5}.gif"))
      end
    end
    
  end
  
  class GObject
    attr_accessor :x, :y, :image

    def initialize(x, y, pic)
      @x, @y, @image = x, y, pic
      render
    end
    
    def render
      @image.move(@x, @y)
    end
    
    def move(dx, dy)
      @x += dx
      @y += dy
    end
  end

  class Bullet < GObject
    attr_accessor :life
    def initialize x,y
      super(x, y, $s.image('images/bullet.gif'))
      @life = 0
    end

    def move
      super(0, -10)
      @life += 1
    end
  end

  class Ship < GObject
    def move(dx, dy)
      x = @x + dx
      y = @y + dy
      if x < 550 && x > 0 && y > 0 && y < 600
        super(dx, dy)
      end
    end
  end
  
  class NPC < GObject
    def move
      super(0, 1)
    end
  end

end
